#ifndef CONVEXHULL3D_H
#define CONVEXHULL3D_H

#include "../doc/document.h"

class ConvexHull3D
{
public:
    static void run(Mesh &mesh);
};

#endif // CONVEXHULL3D_H
