#ifndef MESHCONSTRUCTION_H
#define MESHCONSTRUCTION_H

#include "../doc/mesh.h"
#include <iostream>

using namespace std;

class MeshConstruction
{
public:
    static void BMeshInit(Mesh &m);
};

#endif // MESHCONSTRUCTION_H
