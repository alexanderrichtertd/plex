#ifndef TRIANGLESTOQUADS_H
#define TRIANGLESTOQUADS_H

#include "../doc/mesh.h"

class TrianglesToQuads
{
public:
    static void run(Mesh &mesh);
};

#endif // TRIANGLESTOQUADS_H
