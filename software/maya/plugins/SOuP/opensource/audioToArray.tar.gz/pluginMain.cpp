#include <maya/MFnPlugin.h> 
#include "audioToArray.h"

MStatus initializePlugin(MObject obj)
{ 
	MStatus status;
	MFnPlugin plugin(obj, "", "", "");
	status = plugin.registerNode("audioToArray", audioToArray::id, audioToArray::creator, audioToArray::initialize);
	return status;
}

MStatus uninitializePlugin(MObject obj)
{
	MStatus status;
	MFnPlugin plugin(obj);
	status = plugin.deregisterNode(audioToArray::id);
	return status;
}
