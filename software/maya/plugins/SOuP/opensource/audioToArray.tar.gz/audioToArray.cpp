#include "audioToArray.h"
#include "../pluginMain.h"

MTypeId audioToArray::id(ID_AUDIOTOARRAY);
MObject audioToArray::aInGeo;
MObject audioToArray::aOutBands;
MObject audioToArray::aOutArray;
MObject audioToArray::filePath;
MObject audioToArray::inTime;
MObject audioToArray::offset;
MObject audioToArray::aTimeScale;
MObject audioToArray::samplesNumber;
MObject audioToArray::ampScale;
MObject audioToArray::fftScaling;
MObject audioToArray::bandsNumber;
MObject audioToArray::aModulate;
MObject audioToArray::aInterpolate;

void* audioToArray::creator()
{
	return new audioToArray();
}

void audioToArray::postConstructor()
{
	MObject o = thisMObject();

	MRampAttribute ra(o, aModulate);
	float v = 1.0;
	ra.setValueAtIndex(v, 0);
	ra.setInterpolationAtIndex(MRampAttribute::kSmooth, 0);

	MRampAttribute ra2(o, aInterpolate);
	ra2.setInterpolationAtIndex(MRampAttribute::kSmooth, 0);
	MFloatArray fArrP(1, 1.0);
	MFloatArray fArrV(1, 1.0);
	MIntArray nArrI(1, 1);
	ra2.addEntries(fArrP, fArrV, nArrI);
}

MStatus audioToArray::initialize()
{
	MFnGenericAttribute gAttr;
	MFnUnitAttribute uAttr;
	MFnNumericAttribute nAttr;
	MFnTypedAttribute tAttr;
	MFnEnumAttribute eAttr;
	MRampAttribute rAttr;

	aInGeo = gAttr.create("inGeometry", "ig");
	gAttr.addDataAccept(MFnData::kMesh);
	gAttr.addDataAccept(MFnData::kNurbsCurve);
	gAttr.addDataAccept(MFnData::kNurbsSurface);
	gAttr.addDataAccept(MFnData::kVectorArray);
	gAttr.setStorable(false);

	aOutBands = nAttr.create("outBands", "ob", MFnNumericData::kFloat, 0.0);
	nAttr.setArray(true);
	nAttr.setUsesArrayDataBuilder(true);
	nAttr.setWritable(false);

	aOutArray = tAttr.create("outArray", "oa", MFnData::kDoubleArray);
	nAttr.setWritable(false);
	nAttr.setStorable(false);

	filePath = tAttr.create("filePath", "fp", MFnData::kString);

	inTime = uAttr.create("inTime", "it", MFnUnitAttribute::kTime, 0.0);
	uAttr.setKeyable(true);

	offset = uAttr.create("timeOffset", "to", MFnUnitAttribute::kTime, 0.0);
	uAttr.setKeyable(true);

	aTimeScale = nAttr.create("timeScale", "ts", MFnNumericData::kFloat, 1.0);
	nAttr.setKeyable(true);

	samplesNumber = eAttr.create("samples", "sam", 3);
	eAttr.addField("512", 0);
	eAttr.addField("1024", 1);
	eAttr.addField("2048", 2);
	eAttr.addField("4096", 3);
	eAttr.addField("8192", 4);
	eAttr.setKeyable(true);

	fftScaling = eAttr.create("fftScaling", "fs", 1);
	eAttr.addField("No Scaling", 0);
	eAttr.addField("Square Root", 1);
	eAttr.addField("Average Log", 2);
	eAttr.setKeyable(true);

	ampScale = nAttr.create("ampScale", "as", MFnNumericData::kFloat, 1.0);
	nAttr.setMin(0.001);
	nAttr.setKeyable(true);

	bandsNumber = nAttr.create("bands", "bds", MFnNumericData::kInt, 32); 
	nAttr.setMin(3);
	nAttr.setMax(1024);
	nAttr.setKeyable(true);

	aModulate = rAttr.createCurveRamp("modulate", "mod");

	aInterpolate = rAttr.createCurveRamp("interpolate", "ipl");

	addAttribute(aInGeo);
	addAttribute(aOutBands);
	addAttribute(aOutArray);
	addAttribute(filePath);
	addAttribute(inTime);
	addAttribute(offset);
	addAttribute(aTimeScale);
	addAttribute(samplesNumber);
	addAttribute(ampScale);
	addAttribute(fftScaling);
	addAttribute(bandsNumber);
	addAttribute(aModulate);
	addAttribute(aInterpolate);

	attributeAffects(filePath, aOutBands);
	attributeAffects(inTime, aOutBands);
	attributeAffects(offset, aOutBands);
	attributeAffects(aTimeScale, aOutBands);
	attributeAffects(ampScale, aOutBands);
	attributeAffects(fftScaling, aOutBands);
	attributeAffects(bandsNumber, aOutBands);
	attributeAffects(aModulate, aOutBands);

	attributeAffects(aInGeo, aOutArray);
	attributeAffects(filePath, aOutArray);
	attributeAffects(inTime, aOutArray);
	attributeAffects(offset, aOutArray);
	attributeAffects(aTimeScale, aOutArray);
	attributeAffects(ampScale, aOutArray);
	attributeAffects(fftScaling, aOutArray);
	attributeAffects(bandsNumber, aOutArray);
	attributeAffects(aModulate, aOutArray);
	attributeAffects(aInterpolate, aOutArray);

	return MS::kSuccess;
} 

audioToArray::audioToArray()
{
	currentFilePath = "";

	sampleRate = 44100;
	halfLife = 0.5;
	gain = 1/32768.0;
	nBands = 32;

	nBytes = 2;
	nChannels = 2;
	bits = 16;
	nSamples = 4096;

	newAmpLeft = 0;
	newAmpRight = 0;

	songLength = 0;

	nfftResult = (int)(nSamples*0.5+1);

	fftRawArray.setLength(nfftResult);

	fftin = new float[nSamples];
	fftout = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * nSamples);
	p = fftwf_plan_dft_r2c_1d(nSamples, fftin, fftout, FFTW_MEASURE);
	fftMag = new float[nfftResult];

	fftBands = new float[nBands];
	fftBandsTemp = new float[nBands];
	powerN = log10((double)nfftResult)/nBands;

	buffer = new short[nSamples*nChannels];
}

audioToArray::~audioToArray()
{
	delete[] buffer;

	fftwf_destroy_plan(p);
	fftwf_free(fftout);
	delete[] fftin;
	delete[] fftMag;

	delete[] fftBands;
	delete[] fftBandsTemp;

	if(songLength != 0)
	{
		mySound->close();
		delete mySound;
		delete currentChunk;
	}
}

MStatus audioToArray::compute(const MPlug& plug, MDataBlock& data)
{
	if(data.outputValue(state).asShort() == 2) return MS::kUnknownParameter;

	if(plug == aOutBands || plug == aOutArray)
	{
		MDataHandle filePathHandle = data.inputValue(filePath);

		MString newFilePath = filePathHandle.asString();
		if(updateFilePath(newFilePath) != MS::kSuccess) return MS::kFailure;

		int newNSamples = data.inputValue(samplesNumber).asInt();
		if(newNSamples < 0) newNSamples = 0;
		else if(newNSamples > 4) newNSamples = 4;
		updateNSamples(newNSamples);

		curAmpScale = data.inputValue(ampScale).asFloat();
		if(curAmpScale < 0.01) curAmpScale = 0.01;

		MTime currentTime = data.inputValue(inTime).asTime();
		currentTime.setUnit(MTime::kSeconds);

		MTime currentOffset = data.inputValue(offset).asTime();
		currentOffset.setUnit(MTime::kSeconds);

		float fTimeScale = data.inputValue(aTimeScale).asFloat();

		int currentSample = (int)((currentTime.value()*fTimeScale-currentOffset.value())*sampleRate+0.5)-(int)(nSamples*0.5);
		if(currentSample < 0) currentSample = 0;
		if(currentSample < (int)songLength)
		{
			mySound->read(*currentChunk, currentSample, 0);

			MDataHandle bandsHandle = data.inputValue(bandsNumber);
			int newBandsNumber = bandsHandle.asInt();
			if(newBandsNumber < 3) newBandsNumber = 3;
			else if(newBandsNumber > 1024) newBandsNumber = 1024;
			updateBands(newBandsNumber);

			MDataHandle fftScalingHandle = data.inputValue(fftScaling);
			curFftScaling = fftScalingHandle.asShort();
			if(curFftScaling < 0) curFftScaling = 0;
			else if(curFftScaling > 2) curFftScaling = 2;

			fftw(currentChunk);

			if(plug == aOutBands)
			{
				MArrayDataBuilder adb = data.outputArrayValue(aOutBands).builder();
				for(int i = 0; i < nBands; i++) 
				{       
					MDataHandle outputDataElem = adb.addElement(i);
					outputDataElem.set(fftBands[i]);
				}
				data.outputArrayValue(aOutBands).set(adb);
			}

			if(plug == aOutArray)
			{
				float f = 0.0;
				MStatus status;
				MObject o = thisMObject();
				MRampAttribute ra(o, aModulate);
				for(int i = 0; i < nBands; i++)
				{
					ra.getValueAtPosition(i/(float)nBands, f, &status, MDGContext::fsNormal);
					fftBands[i] = fftBands[i]*f;
				}

				MDoubleArray a;
				MRampAttribute ra2(o, aInterpolate);
				if(MPlug(o, aInGeo).isConnected() == false)
				{
					a.setLength(nBands);
					for(int i = 0; i < nBands; i++) a[i] = fftBands[i];
				}
				else
				{
					MDataHandle dh = data.inputValue(aInGeo);
					unsigned int c = MItGeometry(dh).count();
					int idx = 0;
					float wgt = 0.0;
					a.setLength(c);
					for(unsigned int i = 0; i < c; ++i)
					{
						wgt = i/(float)c * nBands;
						idx = (int)floor(wgt);
						wgt -= idx;
						ra2.getValueAtPosition(wgt, wgt, &status, MDGContext::fsNormal);
						a[i] = fftBands[idx]*(1.0-wgt) + fftBands[idx+1]*wgt;
					}
				}

				MFnDoubleArrayData fn;
				o = fn.create(a);
				data.outputValue(aOutArray).set(o);
			}
		}

		data.setClean(plug);
	}
	else
		return MS::kUnknownParameter;

	return MS::kSuccess;
}

void audioToArray::peak(StkFrames* data)
{
	float inL = 0;
	float inR = 0;

	for(int i = 0; i<nSamples; i++)
	{
		if(nChannels == 1)
		{
			inL = fabs((float)data->interpolate(i,0)*gain);
			if(inL >= newAmpLeft) {newAmpLeft = inL;}
		}
		else if(nChannels == 2)
		{
			inL = fabs((float)data->interpolate(i,0)*gain);
			if(inL >= newAmpLeft) {newAmpLeft = inL;}

			inL = fabs((float)data->interpolate(i,1)*gain);
			if(inR >= newAmpRight) {newAmpRight = inR;}
		}
		else
			std::cout << "nChannels error" <<std::endl;
	}
}

MStatus audioToArray::updateFilePath(MString newFilePath)
{
	if(newFilePath != currentFilePath)
	{
		if (songLength != 0)
		{
			mySound->close();
			delete mySound;
			delete currentChunk;
		}

		mySound = new FileRead(newFilePath.asChar(), true);
		songLength = mySound->fileSize();

		nChannels = mySound->channels();
		currentChunk = new StkFrames(nSamples,nChannels);

	}
	else if(currentFilePath == "")
	{
		std::cout << "No File" << std::endl;
		return MS::kFailure;
	}

	return MS::kSuccess;
}

void audioToArray::updateBands(int newBandsNumber)
{
	if(newBandsNumber != nBands)
	{
		nBands = newBandsNumber;
		powerN = log10((double)nfftResult)/nBands;

		delete[] fftBands;
		delete[] fftBandsTemp;
		fftBands = new float[nBands];
		fftBandsTemp = new float[nBands];
	}
}

void audioToArray::updateNSamples(int newNSamples)
{
	int tempSamples = (int)(pow((double)2, 9+newNSamples));
	if (tempSamples != nSamples)
	{
		nSamples = tempSamples;

		delete[] buffer;

		fftwf_destroy_plan(p);
		fftwf_free(fftout);
		delete[] fftin;
		delete[] fftMag;

		delete[] fftBands;
		delete[] fftBandsTemp;

		nfftResult = (int)(nSamples*0.5+1);
		fftRawArray.setLength(nfftResult);

		fftin = new float[nSamples];
		fftout = (fftwf_complex*) fftwf_malloc(sizeof(fftwf_complex) * nSamples);
		p = fftwf_plan_dft_r2c_1d(nSamples, fftin, fftout, FFTW_MEASURE);
		fftMag = new float[nfftResult];

		fftBands = new float[nBands];
		fftBandsTemp = new float[nBands];
		powerN = log10((double)nfftResult)/nBands;

		buffer = new short[nSamples*nChannels];
	}
}

void audioToArray::fftw(StkFrames* buffer)
{
	double window, imag, real;
	for(int k = 0; k < nSamples; k++)
	{
		window = -.5f*cos(2.*M_PI*k/nSamples)+.5f;
		if(nChannels == 2)
			fftin[k] = (float)(((float)buffer->interpolate(k,0)+(float)buffer->interpolate(k,1))*0.5*gain * window);
		else if(nChannels == 1)
			fftin[k] = (float)((float)buffer->interpolate(k,0)*gain * window);
	}

	fftwf_execute(p);
	for(int k = 0; k < nfftResult; k++)
	{
		real = fftout[k][0];
		imag = fftout[k][1];

		fftMag[k] = (float)sqrt(real*real + imag*imag);
		fftRawArray.set(fftMag[k]*curAmpScale, k);
	}

	int freq = 0;
	int freqlast = 0;
	float result = 0;

	for(int i=1; i<=nBands; i++)
	{
		float sum = 0.0f;
		float sumAvg = 0.0f;
		
		freqlast = freq;
		freq = (int)(pow((double)10, i*powerN)+0.5);
		if(freq >= nfftResult) freq = nfftResult - 1;

		if(freqlast == freq) freqlast = freq-1;
		int bsize = freq-freqlast;

		for(;freqlast < freq; freqlast++)
			sum += fftMag[freqlast];

		if(curFftScaling == 0)
		{
			sum = (float)(sum/500.0);
			result = sum;
		}
		else if(curFftScaling == 1)
		{
			sum = (float)(sum/500.0);
			result = (float)sqrt((double)sum);
		}

		else if(curFftScaling == 2)
		{
			sumAvg = (float)sum/bsize;

			if (sumAvg > 0.01)
				sumAvg = (float)(log((double)sumAvg) + 4.6);
			else
				sumAvg = 0;

			result = (float)(sumAvg/10.0);
		}

		fftBandsTemp[i-1] = result;
		fftBands[i-1] = fftBandsTemp[i-1]*curAmpScale;
	}
}

double audioToArray::newton(int nBands, int fftsize)
{
	double x = 0.0; //power?
	int b = nBands; //number of output nBands
	int fs = fftsize; //number of fft values
	double e; //error -> runs to 0
	double fx; //f(x)
	double fx1; //f'(x)
	double p, p2;
	double l;

	fx = -fs; //f(x)
	fx1 = 0.0; //f'(x)

	//values to get started:
	x = 1.0;
	e = 1.0;
	p = 1.0;
	l = 1.0;
	p2 = pow(2.0,(-15.0));

	int count = 0;

	while(fabs(e)> p2)                       //Do Until Abs(dh) < 2 ^ (-15)
	{
		count++;
		for(int i = 1; i<= b; i++)
		{
			p = pow((double)i,x);
			l = log((double)i);
			fx = fx + p;
			fx1 = fx1 + p*l;
		}

		e = -fx/fx1;
		x += e;
		fx = -fs;
		fx1 = 0;
	}

	return x;
}
