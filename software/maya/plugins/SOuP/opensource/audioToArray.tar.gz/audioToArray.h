#include <maya/MPxNode.h>
#include <maya/MIOStream.h>
#include <maya/MFnNumericAttribute.h>
#include <maya/MFnTypedAttribute.h>
#include <maya/MFnUnitAttribute.h>
#include <maya/MFnEnumAttribute.h>
#include <maya/MArrayDataBuilder.h>
#include <maya/MTime.h>
#include <maya/MFnDoubleArrayData.h>
#include <maya/MDoubleArray.h>
#include <maya/MRampAttribute.h>
#include <maya/MFnGenericAttribute.h>
#include <maya/MItGeometry.h>

#include <string>
#include <math.h>

#include "FileRead.h"
#include "fftw3.h"

class audioToArray : public MPxNode
{
public:
	audioToArray();
	virtual ~audioToArray(); 

	virtual MStatus compute(const MPlug& plug, MDataBlock& data);
	void postConstructor();

	static void* creator();
	static MStatus initialize();

	static MTypeId id;
	static MObject aInGeo;
	static MObject aOutBands;
	static MObject aOutArray;
	static MObject filePath;
	static MObject inTime;
	static MObject offset;
	static MObject aTimeScale;
	static MObject samplesNumber;
	static MObject bandsNumber;
	static MObject ampScale;
	static MObject fftScaling;
	static MObject aModulate;
	static MObject aInterpolate;

	MString currentFilePath;
	long songLength;

	float* fftin;
	fftwf_complex *fftout;
	fftwf_plan p;
	float* fftMag;
	MDoubleArray fftRawArray;

	double powerN;
	int nfftResult;
	int nBands;
	float* fftBands;
	float* fftBandsTemp;
	float curAmpScale;
	float curFftScaling;

	float halfLife;
	float sampleRate;
	float gain;

	int nBytes;
	int nChannels;
	int nSamples;
	int bits;

	float newAmpLeft;
	float newAmpRight;

	short* buffer;

	FileRead* mySound;
	StkFrames* currentChunk;

	void peak(StkFrames* data);

	void fftw(StkFrames* buffer);
	double newton(int bands, int fftsize);

	MStatus updateFilePath(MString newFilePath);
	void updateBands(int newBandsNumber);
	void updateNSamples(int newNSamples);
};
